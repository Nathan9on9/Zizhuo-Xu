document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("user");
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirmPassword=document.getElementById("confirmpassword");
    const birthday = document.getElementById("birthday");
    const submitButton = document.getElementById("submit");
    const errorMessage = document.getElementById("error");
    const loginChange=document.getElementById("three");
    const comment=document.getElementById("comment");
    let valid = true;

    function checkName(name) {
        if (name.value.length <= 5) {
            errorMessage.innerHTML += "Name should be longer than 5 characters!!<br>";
            valid = false;
        }
    }

    function checkEmail(email) {
        if (!email.value.endsWith(".com")) {
            errorMessage.innerHTML += "Email should end with '.com'!!<br>";
            valid = false;
        }
    }

    function checkPassword(password) {
        if (password.value.length <= 7) {
            errorMessage.innerHTML += "Password should be longer than 7 characters!!<br>";
            valid = false;
        }
    }

    function checkBirthday(birthday) {
        const birthDate = new Date(birthday.value);
        const today = new Date();
        if (birthDate >= today) {
            errorMessage.innerHTML += "Birthday should be in the past!!<br>";
            valid = false;
        }
    }
    function matchPassword(passwordInput, confirmPasswordInput) {
        if (passwordInput.value !== confirmPasswordInput.value) { 
            errorMessage.innerHTML += "Confirm password should match with password!!<br>";
            valid = false;
        }
    }
    
    function checkComment(comment)
     {
         if(comment.value==="")
         {
            errorMessage.innerHTML += "comment shouldn't be empty<br>";
            valid=false;

         }
     }
    form.addEventListener("submit", function(event) {
        event.preventDefault();
        errorMessage.innerHTML = ''; 
        valid = true; 

        checkName(name);
        checkEmail(email);
        checkPassword(password);
        checkBirthday(birthday);
        matchPassword(password, confirmPassword);
        checkComment(comment);

        if (!valid) {
            
            event.preventDefault();
            errorMessage.style.color="red";
            loginChange.innerHTML="log in";
        }
        else
        {   
            errorMessage.style.color="black";
            errorMessage.innerHTML="Sign up successfully."
            loginChange.innerHTML="hello,"+name.value;
        }
    });
});
