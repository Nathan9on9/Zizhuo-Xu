document.addEventListener("DOMContentLoaded", function() {

    var submitButton = document.getElementById("sbutton");
    var commentInput = document.getElementById("comment");

   
    submitButton.addEventListener("click", function(event) {
      
        event.preventDefault();
        if(commentInput.value !== ''){
        var newComment = commentInput.value;
        var header = document.createElement("header");
        var date = document.createElement("h1");
        var paragraph = document.createElement("p");
        var mainContainer = document.querySelector(".main");
        var newCommentElement = document.createElement("div");

        newCommentElement.classList.add("comment");
        header.textContent = "New User"; 
        newCommentElement.appendChild(header);
        date.textContent = getCurrentDate(); 
        newCommentElement.appendChild(date);
        date.classList.add("date");
        paragraph.textContent = newComment;
        newCommentElement.appendChild(paragraph);
        mainContainer.appendChild(newCommentElement);
        commentInput.value = "";
        }
        else
        {
            alert("comment can't be empty!!!")
        }
    });


    function getCurrentDate() {
        var date = new Date();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var year = date.getFullYear();
        return month + "-" + day + "-" + year;
    }
});
