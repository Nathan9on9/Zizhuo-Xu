document.addEventListener("DOMContentLoaded", function() {

   var showHide=document.getElementById("dropdown");
   showHide.addEventListener("click" ,function(event) {
    event.preventDefault();
    var hiddenElement=document.getElementById("hidden");
    if (hiddenElement.style.display === "none") {
        hiddenElement.style.display = "block";
        showHide.innerHTML = "show less &#9650;"; 
    } else {
        hiddenElement.style.display = "none";
        showHide.innerHTML = "show more&#9660;"; 
    }
});
   



});