document.addEventListener("DOMContentLoaded", function() {
    
    var form = document.querySelector(".layout");
    var submitButton = document.getElementById("submitcolor");
    var resetColor=document.getElementById("Reset");
    submitButton.addEventListener("click", function(event) {
        event.preventDefault();
        var selectedScheme = getSelectedScheme();
        switch (selectedScheme) {
            case "scheme1":
                changeBackgroundColor1();
                break;
            case "scheme2":
                changeBackgroundColor2();
                break;
            case "scheme3":
                changeBackgroundColor3();
                break;
            default:
                break;
        }
    });
     resetColor.addEventListener("click",function(event) {

         event.preventDefault();
         changeBackgroundColor1();
         var radioButtons = form.querySelectorAll("input[type='radio'][name='colorScheme']");
         if (radioButtons.length > 0) {
            radioButtons[0].checked = true;
        }

     });

    function getSelectedScheme() {
        var radioButtons = form.querySelectorAll("input[type='radio'][name='colorScheme']");
        var selectedScheme;
        radioButtons.forEach(function(radioButton) {
            if (radioButton.checked) {
                selectedScheme = radioButton.value; 
            }
        });
        return selectedScheme;
    }
    function changeBackgroundColor1() {
        var allElements = document.querySelectorAll('*');
        var navChange= document.getElementById("nav");
        allElements.forEach(function(element) {
            var computedStyle = window.getComputedStyle(element);
            var backgroundColor = computedStyle.backgroundColor;
            var backgroundLinear = computedStyle.background;
            if (backgroundColor === 'rgb(244, 234, 211)'|| backgroundColor === 'rgb(217, 210, 244)'||backgroundColor === 'rgb(210, 244, 217)') {
                element.style.backgroundColor = 'rgb(244, 234, 211)'; 
                navChange.style.background = 'linear-gradient(to bottom, rgb(212, 182, 159), rgb(244, 234, 211))';
            }
            else if (backgroundColor === 'rgb(210, 244, 217)') {
                element.style.backgroundColor = ''; 
            }
        });
    }
    
    function changeBackgroundColor2() {
        var allElements = document.querySelectorAll('*');
        var navChange= document.getElementById("nav");
        allElements.forEach(function(element) {
            var computedStyle = window.getComputedStyle(element);
            var backgroundColor = computedStyle.backgroundColor;
            var backgroundLinear = computedStyle.background;
            if (backgroundColor === 'rgb(244, 234, 211)' || backgroundColor === 'rgb(217, 210, 244)' ) {
                element.style.backgroundColor = 'rgb(210, 244, 217)'; 
                navChange.style.background = 'linear-gradient(to bottom, rgb(180, 220, 205), rgb(210, 244, 217))';
                document.body.style.backgroundColor = 'rgb(210, 244, 217)';
            } else if (backgroundColor === 'rgb(210, 244, 217)') {
                element.style.backgroundColor = ''; 
            }
        });
    }
    
    function changeBackgroundColor3() {
        var allElements = document.querySelectorAll('*');
        var navChange= document.getElementById("nav");
        allElements.forEach(function(element) {
            var computedStyle = window.getComputedStyle(element);
            var backgroundColor = computedStyle.backgroundColor;
    
            if (backgroundColor === 'rgb(244, 234, 211)' ||backgroundColor === 'rgb(210, 244, 217)') {
                element.style.backgroundColor = 'rgb(217, 210, 244)'; 
                navChange.style.background = 'linear-gradient(to bottom, rgb(190, 180, 230), rgb(217, 210, 244))';
            } else if (backgroundColor === 'rgb(217, 210, 244)') {
                element.style.backgroundColor = ''; 
            }
        });
    }
    if ("Notification" in window) {
        Notification.requestPermission().then(function (permission) {
          if (permission === "granted") {
            const notification = new Notification("This is a notification", {
              body: "New Notification",
              icon: './asset/logo.PNG'
            });
      
            notification.onclick = function () {
              console.log("Notification was clicked!");
            };
          } else {
            console.log("Permission not granted for notifications.");
          }
        });
      } else {
        console.log("Browser does not support notifications.");
      }
});